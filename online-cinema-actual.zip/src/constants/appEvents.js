export const appEvents = {
  validateControls: "validate-controls",
  storage: "storage",
  userAuthorized: "user-authorized",
  userLoggedOut: "user-logged-out",
  changeRoute: "change-route",
};
