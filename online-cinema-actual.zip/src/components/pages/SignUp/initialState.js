export const initialFieldsState = {
  email: {
    value: "",
    errors: {},
    isTouched: false,
    isValid: false,
  },
  password: {
    value: "",
    errors: {},
    isTouched: false,
    isValid: false,
  },
};
