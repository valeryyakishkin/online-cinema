export * from './Admin';
export * from './Home';
export * from './MovieDetails';
export * from './SignIn';
export * from './SignUp';
export * from './Error'